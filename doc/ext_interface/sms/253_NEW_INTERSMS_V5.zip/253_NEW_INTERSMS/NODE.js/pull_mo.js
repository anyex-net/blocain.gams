var http = require('http');

// 修改为您的短信账号
var account="I2170326";
// 修改为您的短信密码
var password="******";
// 拉取个数（最大100，默认20），选填
var count = "20";
// 短信域名地址
var sms_host = 'intapi.253.com';
// 拉取上行短信明细
var pull_mo_uri = '/pull/mo';

pull_mo(pull_mo_uri,account,password,count);

// 拉取上行短信
function pull_mo(uri,account,password,count){
	
    var post_data = { // 这是需要提交的数据 
    'account': account,   
    'password': password, 
	'count':count,
    };  
    var content = JSON.stringify(post_data);  
    post(uri,content,sms_host);
}
function post(uri,content,host){
	var options = {  
        hostname: host,
        port: 80,  
        path: uri,  
        method: 'POST',  
        headers: {  
            'Content-Type': 'application/json; charset=UTF-8', 
        }  
    };
    var req = http.request(options, function (res) {  
        console.log('STATUS: ' + res.statusCode);  
        
        res.setEncoding('utf8');  
        res.on('data', function (chunk) {  
            console.log('BODY: ' + chunk);  
        });  
    }); 
   
    req.write(content);  
  
    req.end();   
} 


