var http = require('http');

// 修改为您的短信账号
var account="I2170326";
// 修改为您的短信密码
var password="******";
// 短信域名地址
var sms_host = 'intapi.253.com';
// 查询余额地址
var query_balance_uri = '/balance/json';


query_blance(query_balance_uri,account,password);


  
// 查询余额方法
function query_blance(uri,account,password){
	
    var post_data = { // 这是需要提交的数据 
    'account': account,   
    'password': password, 
    };  
    var content = JSON.stringify(post_data);  
    post(uri,content,sms_host);
}

function post(uri,content,host){
	var options = {  
        hostname: host,
        port: 80,  
        path: uri,  
        method: 'POST',  
        headers: {  
            'Content-Type': 'application/json; charset=UTF-8', 
        }  
    };
    var req = http.request(options, function (res) {  
        console.log('STATUS: ' + res.statusCode);  
        
        res.setEncoding('utf8');  
        res.on('data', function (chunk) {  
            console.log('BODY: ' + chunk);  
        });  
    }); 
   
    req.write(content);  
  
    req.end();   
} 


