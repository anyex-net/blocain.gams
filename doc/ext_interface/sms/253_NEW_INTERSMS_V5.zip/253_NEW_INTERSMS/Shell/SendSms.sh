#!/bin/sh
# account and password can be change to what you wanna!
#author ChuangLan
#修改为您的account
account="I2170326"
#修改为您的pw
password="******"
#手机号码，格式(区号+手机号码)，例如：8615800000000，其中86为中国的区号
mobile="8615800000000"
#设置您要发送的内容
msg="【253云通讯】您的验证码是123456。如非本人操作，请忽略。"
#用户收到短信之后显示的发件人，国内不支持自定义，国外支持，但是需要提前和运营商沟通注册，具体请与TIG对接人员确定。选填参数
senderId=""
echo "send sms:"

url="http://intapi.253.com/send/json"
data="{\"account\":\"$account\",\"password\":\"$password\",\"mobile\":\"$mobile\",\"msg\":\"$msg\",\"senderId\":\"$senderId\"}"
curl -H "Content-Type:application/json" -X POST --data $data $url

