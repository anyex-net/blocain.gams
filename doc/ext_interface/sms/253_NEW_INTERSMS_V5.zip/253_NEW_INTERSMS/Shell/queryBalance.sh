#!/bin/sh
# account and password can be change to what you wanna!
#author ChuangLan
#修改为您的account
account="I2170326"
#修改为您的pw
password="******"

echo "send sms:"

url="http://intapi.253.com/balance/json"
data="{\"account\":\"$account\",\"password\":\"$password\"}"
curl -H "Content-Type:application/json" -X POST --data $data $url

