#!/bin/sh
# account and password can be change to what you wanna!
#author ChuangLan
#修改为您的account
account="I2170326"
#修改为您的pw
password="******"
#
count="20"
echo "send sms:"

url="http://intapi.253.com/pull/mo"
data="{\"account\":\"$account\",\"password\":\"$password\",\"count\":\"$count\"}"
curl -H "Content-Type:application/json" -X POST --data $data $url

