package main
import (
    "net/http"
    "encoding/json"
    "fmt"
    "bytes"
    "io/ioutil"
    "unsafe"
)
 
type JsonPostSample struct {
 
}
 
func  main() {
    params := make(map[string]interface{})
	// API账号，50位以内。必填
    params["account"] = "I2170326"
    // API账号对应密钥，联系客服获取。必填
    params["password"] = "******"
    bytesData, err := json.Marshal(params)
    if err != nil {
        fmt.Println(err.Error() )
        return
    }
    reader := bytes.NewReader(bytesData)
    url := "http://intapi.253.com/balance/json"
    request, err := http.NewRequest("POST", url, reader)
    if err != nil {
        fmt.Println(err.Error())
        return
    }
    request.Header.Set("Content-Type", "application/json;charset=UTF-8")
    client := http.Client{}
    resp, err := client.Do(request)
    if err != nil {
        fmt.Println(err.Error())
        return
    }
    respBytes, err := ioutil.ReadAll(resp.Body)
    if err != nil {
        fmt.Println(err.Error())
        return
    }
   
    str := (*string)(unsafe.Pointer(&respBytes))
    fmt.Println(*str)
}